<?php

namespace App\Http\Controllers\PC\About;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests;
use Session;
use Config;

class AboutController extends Controller
{

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = 'PC.About.about';

    private $limit;
    private $page;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->page=0;
        $this->limit=4;
    }


    public function index()
    {
//        $data = G_gnews::offset($this->limit * $this->page)->limit($this->limit)->orderBy('created_at', 'desc')->get()->toArray();
//
//        foreach ($data as &$value) {
//            //1）资讯中心 2）本地关注 3）城建动态
//            switch ($value['cate']) {
//                case 1:
//                    $value['category'] = '资讯中心';
//                    break;
//                case 2:
//                    $value['category'] = '本地关注';
//                    break;
//                case 3:
//                    $value['category'] = '城建动态';
//                    break;
//                default:
//                    $value['category'] = '资讯中心';
//            }
//        }

        return view($this->redirectTo);
    }

}
