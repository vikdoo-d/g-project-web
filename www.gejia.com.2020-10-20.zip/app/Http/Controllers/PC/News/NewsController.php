<?php
/**
 * Created by PhpStorm.
 * User: dongkang
 * Date: 2020/9/7
 * Time: 14:40
 */

namespace App\Http\Controllers\PC\News;
use App\Http\Service\Action\ActionService;
use App\Common\ErrorDefine;
use App\Http\Requests;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use Session,Config;

class NewsController extends Controller
{
    /**
     * @return view
     * Demo页面
     */
    public function index()
    {
        return view('PC.News.news');
    }

    public function draft()
    {
        return view('News.news_draft');
    }

    /**
     * @param Request $request
     * @return bool|mixed|string
     * 新闻资讯列表
     */
    public function getNewsList(Request $request)
    {
        $where= $request->except('_token');


        $token = session()->get(Config::get('custom.setting.MEMBER_TOKEN'));

        $where['token'] = $token;

        if($request->has('page'))
        {
            $where['page'] = $request->input('page');
        }else{
            $where['page'] = 1;
        }
        if($request->has('limit'))
        {
            $where['limit'] = $request->input('limit');
        }else{
            $where['limit'] = 10;
        }

        foreach($where as $key=>$value)
        {
            if($value =='' || $value == 'undefined')
            {
                unset($where[$key]);
            }
        }

        $news = new ActionService();
        $data = $news->getNewsList($where);
        return $data;
    }

    /**
     * @param Request $request
     * @return bool|mixed|string
     * 新闻资讯软删除
     */
    public function doNewsSoftDelete(Request $request)
    {
        $where = $request->except('_token');

        $token = session()->get(Config::get('custom.setting.MEMBER_TOKEN'));
        $where['token'] = $token;


        $Action = new ActionService();
        $data = $Action->doNewsSoftDelete($where);

        return $data;
    }


    /**
     * @param Request $request
     * @return mixed
     * 新闻添加
     */
    public function doNewsAdd(Request $request)
    {
        $where = $request->except('_token');
        $token = session()->get(Config::get('custom.setting.MEMBER_TOKEN'));
        $where['token'] = $token;
        foreach($where as $key=>$value)
        {
            if($value =='' || $value == 'undefined')
            {
                unset($where[$key]);
            }
        }

//        dd($where);
        $action = new ActionService();
        $data = $action->doNewsAdd($where);

        return $data;
    }

    /**
     * @param Request $request
     * @return mixed
     * 新闻修改
     */
    public function doNewsUpdate(Request $request)
    {

        $where = $request->except('_token');
        $token = session()->get(Config::get('custom.setting.MEMBER_TOKEN'));
        $where['token'] = $token;
        foreach($where as $key=>$value)
        {
            if($value =='' || $value == 'undefined')
            {
                unset($where[$key]);
            }
        }

        $action = new ActionService();
        $data = $action->doNewsUpdate($where);
        return $data;
    }
}