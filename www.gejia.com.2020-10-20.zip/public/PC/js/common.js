/**
 * Created by Vikdoo on 2020/9/22.
 */
$(window).on('load', function () {
    if ($('#preloader').length) {
        $('#preloader').delay(200).fadeOut('slow', function () {
            $(this).remove();
        });
    }
});
$(function(){


    showScroll();
    function showScroll(){
        $(window).scroll( function() {
            var scrollValue=$(window).scrollTop();
            scrollValue > 100 ?  $('.back-to-top').fadeIn():$('.back-to-top').fadeOut();
        } );
        $('.back-to-top').click(function(){
            $("html,body").animate({scrollTop:0},1000);
            return false;
        });
    }

    listScroll();
    function listScroll(){
        var len1 = $(".scroll_a li").length;
        var len2 = $(".scroll_b li").length;

        if(len1 > 7){
            $(".main-news-a .about-new-list .scroll_a").i5Scroll();
        }
        if(len2 > 7){
            $(".main-news-b .about-new-list .scroll_b").i5Scroll();
        }
        $(".news-content-b .new_list .scroll_c").i5Scroll();
    }


    imgScroll();
    function imgScroll(){
        $('.succesny').olvSlides({
            thumb: true,
            thumbPage: true,
            thumbDirection: "Y",
            effect: 'fade'
        });

        $(".ssprev,.ssnext,.thumbPrev,.thumbNext").css("display","none");
        $('.control').hover(function(){
            $(".ssprev,.ssnext").css("display","block");
        },function () {
            $(".ssprev,.ssnext").css("display","none");
        })
        $('.thumbWrap').hover(function(){
            $(".thumbPrev,.thumbNext").css("display","block");
        },function () {
            $(".thumbPrev,.thumbNext").css("display","none");
        })
    }



    // autoAdjust()
    function autoAdjust (targetWidth = 1920) {
        const isFox =
            navigator.userAgent.indexOf('Firefox') > -1 ? true : false;
        let adjustWindow = () => {
            const ratio = document.documentElement.clientWidth / targetWidth;
            const htmlHeight =
                (document.documentElement.clientHeight * targetWidth) / document.documentElement.clientWidth + 'px';

            document.documentElement.style.height = htmlHeight;
            if (isFox) {
                document.documentElement.style.transform = `scale(${ratio})`;
            } else {
                document.documentElement.style.zoom = ratio;
            }
            document.documentElement.setAttribute('data-ratio', ratio);
            let allTag = document.getElementsByTagName('*')
            for (let i = 0; i < allTag.length; i++) {
                const currentMarginTop = window.getComputedStyle(allTag[i]).marginTop
                if (currentMarginTop !== '0px' || currentMarginTop !== 'auto') {
                    allTag[i].style.marginTop = Number(currentMarginTop.slice(0, -2)) * (document.documentElement.clientHeight / 1080 / ratio) + 'px'
                }
                const paddingTop = window.getComputedStyle(allTag[i]).paddingTop
                if (paddingTop !== '0px' || paddingTop !== 'auto') {
                    allTag[i].style.paddingTop = Number(paddingTop.slice(0, -2)) * (document.documentElement.clientHeight / 1080 / ratio) + 'px'
                }
            }
        };
        adjustWindow();
        window.addEventListener('resize', adjustWindow);
        // 使鼠标坐标一致
        let x_get = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'x')
            .get;
        let y_get = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'y')
            .get;
        Object.defineProperties(MouseEvent.prototype, {
            R: {
                get: function () {
                    return parseFloat(
                        document.documentElement.getAttribute('data-ratio')
                    );
                }
            },
            x: {
                get: function () {
                    return x_get.call(this) / this.R;
                }
            },
            y: {
                get: function () {
                    return y_get.call(this) / this.R;
                }
            }
        });
        if (isFox) {
            let getBoundingClientRect = Element.prototype.getBoundingClientRect;
            Element.prototype.getBoundingClientRect = function () {
                let value = getBoundingClientRect.call(this);
                let ratio = parseFloat(
                    document.documentElement.getAttribute('data-ratio')
                );
                value = new Proxy(value, {
                    get: function (target, proper) {
                        return Reflect.get(target, proper) / ratio;
                    }
                });
                return value;
            };
        }
    }
    // document.getElementById('dataContainer').style.zoom = document.documentElement.clientHeight / 1080 / zoom
});


