<!--/ footer Star /-->
<section class="section-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-4">
                <div class="widget-a">
                    <div class="w-header-a">
                        <h3 class="w-title-a text-brand">格家</h3>
                    </div>
                    <div class="w-body-a">
                        <p class="w-text-a color-text-a">
                            为更多的人找到满意的家
                        </p>
                    </div>
                    <div class="w-footer-a">
                        <ul class="list-unstyled">
                            <li class="color-a">
                                <span class="color-text-a">客服电话 .</span> 400-800-0080</li>
                            {{--<li class="color-a">--}}
                                {{--<span class="color-text-a">邮箱 .</span> +54 356 945234</li>--}}
                            {{--<li class="color-a">--}}
                                {{--<span class="color-text-a">法律咨询 .</span> +54 356 945234</li>--}}
                            <li class="color-a">
                                <span class="color-text-a">地址 .</span> 镜湖区万达一期3号写字楼18楼（格家房产总部办公室）</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 section-md-t3">
                <div class="widget-a">
                    <div class="w-header-a">
                        <h3 class="w-title-a text-brand">关于公司</h3>
                    </div>
                    <div class="w-body-a">
                        <div class="w-body-a">
                            <ul class="list-unstyled">

                                {{--<li class="item-list-a">--}}
                                    {{--<i class="fa fa-angle-right"></i> <a href="#">法律业务</a>--}}
                                {{--</li>--}}
                                {{--<li class="item-list-a">--}}
                                    {{--<i class="fa fa-angle-right"></i> <a href="#">经纪人后台</a>--}}
                                {{--</li>--}}
                                {{--<li class="item-list-a">--}}
                                    {{--<i class="fa fa-angle-right"></i> <a href="#">公司招聘</a>--}}
                                {{--</li>--}}
                                <li class="item-list-a">
                                    <i class="fa fa-angle-right"></i> <a href="javascript:;">合作伙伴</a>
                                </li>
                                {{--<li class="item-list-a">--}}
                                    {{--<i class="fa fa-angle-right"></i> <img src="/PC/img/web/wx1599724978.jpg">--}}
                                {{--</li>--}}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 section-md-t3">
                <div class="widget-a">
                    <div class="w-header-a">
                        <h3 class="w-title-a text-brand">友情链接</h3>
                    </div>
                    <div class="w-body-a">
                        <ul class="list-unstyled">
                            <li class="item-list-a">
                                <i class="fa fa-angle-right"></i> <a href="http://www.qiaofang.cn/">巧房</a>
                            </li>
                            <li class="item-list-a">
                                <i class="fa fa-angle-right"></i> <a href="#">鸠江区</a>
                            </li>
                            <li class="item-list-a">
                                <i class="fa fa-angle-right"></i> <a href="#">弋江区</a>
                            </li>
                            <li class="item-list-a">
                                <i class="fa fa-angle-right"></i> <a href="#">三山区</a>
                            </li>
                            {{--<li class="item-list-a">--}}
                                {{--<i class="fa fa-angle-right"></i> <a href="#">芜湖县</a>--}}
                            {{--</li>--}}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright-footer">
                    <p class="copyright color-text-a">
                        &copy; Copyright
                        <span class="color-a">www.gejia.cn</span> 保留所有权利，侵权必究。
                    </p>
                </div>
                <div class="credits">
                    技术支持 <a href="#" target="_blank" title="格家房产经纪">格家房产</a> - 开发 by <a href="http://www.vikdoo.com/" title="技术人员" target="_blank">www.vikdoo.com</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--/ Footer End /-->

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<div id="preloader"></div>

<!-- JavaScript Libraries -->
<script src="/PC/lib/jquery/jquery.min.js"></script>
<script src="/PC/lib/jquery/jquery-migrate.min.js"></script>
<script src="/PC/lib/popper/popper.min.js"></script>
<script src="/PC/lib/bootstrap/js/bootstrap.min.js"></script>
<script src="/PC/lib/easing/easing.min.js"></script>
<script src="/PC/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="/PC/lib/scrollreveal/scrollreveal.min.js"></script>

<!-- Contact Form JavaScript File -->
<script src="/PC/contactform/contactform.js"></script>
<!-- Template Main Javascript File -->
<script src="/PC/js/main.js"></script>
<script src="/PC/js/common.js"></script>

