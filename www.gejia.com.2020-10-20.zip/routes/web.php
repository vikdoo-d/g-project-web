<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//页面 显示
Route::get('/', 'PC\Index\IndexController@index'); //首页
Route::get('/coding',function(){
    return view('welcome');
});
Route::get('/about', 'PC\About\AboutController@index'); //关于我们

Route::get('/news','PC\News\NewsController@index'); //新闻

Route::get('/news_info?1','PC\News\NewsController@news_info');

Route::get('/careers','PC\Careers\CareersController@index'); //联系我们

Route::get('/ppy','PC\Ppy\PpyController@index'); //房源列表页

Route::get('/ppy_info','PC\Ppy\PpyController@ppy_info'); //房源详情页

Route::get('/agent','PC\Agent\AgentController@index'); //经纪人列表

Route::get('/agent_info','PC\Agent\AgentController@agent_info'); //经纪人详情

Route::get('/map', 'PC\Index\IndexController@map');

//功能
//Route::get('/get_agent_list','Agent\AgentController@getAgentList');
Route::get('/get_news_list','PC\News\NewsController@getNewsList');

Route::post('/submit','PC\Contact\ContactController@FeedbackAdd');
//
