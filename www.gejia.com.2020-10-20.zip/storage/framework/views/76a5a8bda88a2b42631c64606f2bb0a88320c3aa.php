<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta content="芜湖格家房产经纪有限公司，芜湖格家，二手房，芜湖房价，租房，格家，格家房产，房产，十年口碑，限时独家，海量房源，专业承诺" name="keywords">
    <title>芜湖格家房产经纪有限公司-专注房产经纪十周年</title>
    <!-- Libraries CSS Files -->
    <link href="/PC/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link href="/PC/lib/animate/animate.min.css" rel="stylesheet">
    <link href="/PC/css/common.css" rel="stylesheet">
    <link href="/PC/css/index.css" rel="stylesheet">

</head>
<body>
<div>
    <div class="index-intro" style="">
        <header class="navbar">
            <div class="logo-icon" style="float:left">
                <a class="navbar-brand text-brand" href="/"><img src="/PC/img/logo.png"></a>
            </div>
            <div id="navbarDefault">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/coding">二手房</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/coding">新房</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/coding">租房</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/news">房产快讯</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">关于我们</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">加入我们</a>
                    </li>
                </ul>
            </div>

        </header>
        <div class="service-title">
            <img class="door" src="/PC/img/door.png" >
            <h2>为更多人找到满意的家</h2>
            <span> 十年口碑 / 限时独家 / 海量房源 / 专业承诺 / 真诚服务</span>
            <img class="line" src="/PC/img/line.png">
        </div>

    </div>
    <div class="intro-part">
        <div class="container">
            <div class="intro-title">
                <div class="title-box">
                    <h1>关于格家</h1>
                    <p>为更多的人找到满意的家</p>
                </div>
            </div>
            <div class="intro-content">
                <div class="intro-video">
                    <video src="/PC/img/movie.ogv" class="video-about" controls="controls"></video>
                </div>
                <div class="intro-normal">
                    <div class="intro-ltd">
                        <h3>企业简介</h3>
                        <div><a>了解更多 <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i></a></div>
                    </div>

                    <div class="intro-text">
                        <p class="color-text-a">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格家，2010年创立于安徽芜湖，历经十年的磨砺与成长，
                            现已发展成为拥有60余家直营连锁门店、拥有500多人的年轻职业化精英团队，
                            是芜湖直营连锁中介的开拓者。
                        </p>
                        <p class="color-text-a">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;公司主营二手房买卖租赁、新房联动销售，
                            范围涉及住宅、别墅、写字楼、商铺等，
                            同时提供代办房屋过户、按揭贷款、代办产权交易过户等服务。

                        </p>
                        <p class="color-text-a">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格家坚持以“人真、心诚、事久”为核心价值观，并始终秉承“为更多人找到满意的家”的服务理念，
                            10年来格家人用脚步丈量着芜湖的每一个社区和商圈，不断地提升专业，细化服务。
                            未来我们将继续践行公司的企业文化，竭诚为江城百姓置业安！
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="ershoufang">
        <div class="container">
            <div class="intro-title">
                <div class="title-box">
                    <h1>二手好房</h1>
                    <p>二手好房源，独家推荐 </p>
                    <div class="title-link">
                        <a href="/coding">查看更多二手好房
                            <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

            </div>
            <div id="property-box" class="ppy-box">
                <ul>
                    <!--<?php echo e(&#45;&#45;<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!--<?php echo e(&#45;&#45;<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <section class="new-house">
        <div class="container">
            <div class="intro-title">
                <div class="title-box">
                    <h1>优选新房</h1>
                    <p>真实信息准确同步，楼盘动态一手掌握 </p>
                    <div class="title-link">
                        <a href="/coding">查看更多新房
                            <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>

            </div>
            <div class="ppy-box">
                <ul>
                    <!--<?php echo e(&#45;&#45;<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!--<?php echo e(&#45;&#45;<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ppy-box-a">
                        <div class="ppy-box-b">
                            <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                 alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                            <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                            <div class="bottom">
                                <div class="ppy-name">
                                    <p>闵行·闵浦</p>
                                    <p>金硕河畔景园东区</p>
                                </div>
                                <div class="ppy-info">
                                    2室2厅 · 71.98平米
                                    <div class="price">235万
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <section class="agent">
        <div class="container">
            <div class="intro-title">
                <div class="title-box">
                    <h1>金牌经纪人</h1>
                    <p>为更多的人找到满意的家 </p>
                    <!--<div class="title-link">-->
                        <!--<a href="/coding">查看更多-->
                            <!--<i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>-->
                        <!--</a>-->
                    <!--</div>-->
                </div>

            </div>
            <div class="agent-box">
                <ul>
                    <!--<?php echo e(&#45;&#45;<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <!--<?php echo e(&#45;&#45;<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&#45;&#45;); ?>-->
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                    <li class="agent-box-a">
                        <div class="agent-box-b" style="">
                            <img class="agent-avater" src="/PC/img/avater.png">
                            <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                 alt="经纪人姓名" title="经纪人姓名">
                            <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                            <div class="bottom">
                                <div class="agent-name">
                                    <p>孙路路</p>
                                    <span>好评经纪人，熟悉本房特色</span>
                                </div>
                                <div class="agent-mobile">
                                    13356783456
                                </div>
                            </div>
                        </div>

                    </li>
                </ul>
                <div class="clearfix"></div>
                <a id="prev" class="prev" href="#">&lt;</a>
                <a id="next" class="next" href="#">&gt;</a>
                <div id="pager" class="pager"></div>
            </div>
        </div>
    </section>

    <section class="map">
        <div class="container">
            <div class="intro-title">
                <div class="title-box">
                    <h1>门店地图</h1>
                    <p>格家门店，覆盖全城 </p>
                    <div class="title-link">
                        <a target="_blank" href="https://map.baidu.com/search/%E6%A0%BC%E5%AE%B6%E6%88%BF%E4%BA%A7/@13183796.58,3657846.6,15z?querytype=s&c=129&wd=%E6%A0%BC%E5%AE%B6%E6%88%BF%E4%BA%A7&da_src=shareurl&on_gel=1&l=15&gr=1&b=(13177652.58,3654830.6;13189940.58,3660862.6)&pn=0&device_ratio=2">更多门店地址
                            <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div>
                <div class="contact-map-box">
                    <div id="map" class="contact-map">
                        <iframe src="/map?id=2" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen>

                        </iframe>
                    </div>
                </div>
            </div>

            <div class="wrap" id="wrap">
                <ul class="content"></ul>
                <a href="javascript:;" class="prev"><i>&#60;</i></a>
                <a href="javascript:;" class="next"><i>&#62;</i></a>
            </div>
        </div>


    </section>

    <div class="end">
        <footer class="footer">
                <div class="footer_main">
                    <div class="footer_left">
                        <img src="/PC/img/wechat.jpg" />
                        <img class="footer-sign" src="/PC/img/sign.png" />
                        <p style="color: #fff;font-size: 14px;display: inline-block;position: relative;left: -170px;top:18px">关注公众号，查看真房源</p>
                        <p style="color: #fff;font-size: 14px;display: inline-block;position: relative;left: 58px;top:-20px"> 十年口碑 / 限时独家 / 海量房源 / 专业承诺 / 真诚服务</p>


                    </div>

                    <div class="footer_right">
                        <img src="/PC/img/logo.png" />
                        <p style="color: #fff;font-size: 14px;"> 地址： 芜湖镜湖区万达广场一期三号楼</p>
                        <p style="color: #fff;font-size: 14px;"> 邮编： 241000 <span> &nbsp;&nbsp;&nbsp;全国热线： 400-800-0080</span></p>
                    </div>
                </div>

                <div class="copyright-footer">
                    <p class="copyright">
                       Copyright &copy;
                        <span class="color-a">安徽格家房产经纪有限公司</span> | 皖ICP备2020016524号
                    </p>
                </div>

        </footer>
    </div>

    <a href="#" class="back-to-top" style="display: none;"><i class="fa fa-chevron-up"></i></a>
</div>
<script src="/PC/lib/jquery/jquery.min.js"></script>
<script src="/PC/lib/jquery/jquery-migrate.min.js"></script>
<script src="/PC/lib/scrollreveal/scrollreveal.min.js"></script>
<script src="/PC/lib/jquery.carouFredSel-6.0.4-packed.js"></script>
<script src="/PC/lib/tools.js"></script>
<script src="/PC/js/main.js"></script>
<script type="text/javascript">
    $(function() {

        $('.agent-box ul').carouFredSel({
            prev: '#prev',
            next: '#next',
            pagination: "#pager",
            scroll: 1000
        });

    });
</script>
</body>
</html><?php /**PATH D:\Code\www.vikdoo.com\resources\views/PC/index.html ENDPATH**/ ?>