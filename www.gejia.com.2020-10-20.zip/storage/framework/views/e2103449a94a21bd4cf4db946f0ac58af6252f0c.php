<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>格家</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <script src="/vue.js"></script>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>

        <section class="ershoufang">
            <div class="container">
                <div class="intro-title">
                    <div class="title-box">
                        <h1>二手好房</h1>
                        <p>二手好房源，独家推荐 </p>
                        <div class="title-link">
                            <a href="/coding">查看更多二手好房
                                <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>

                </div>
                <div id="property-box" class="ppy-box">
                    <ul>

                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/e_f_1.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/e_f_2.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>


        <section class="new-house">
            <div class="container">
                <div class="intro-title">
                    <div class="title-box">
                        <h1>优选新房</h1>
                        <p>真实信息准确同步，楼盘动态一手掌握 </p>
                        <div class="title-link">
                            <a href="/coding">查看更多新房
                                <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>

                </div>
                <div class="ppy-box">
                    <ul>

                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="ppy-box-a">
                            <div class="ppy-box-b">
                                <img class="ppy-box-img" src="/PC/img/pc0_ICz33yzMe.jpg"
                                     alt="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖" title="南北通户型 落地阳台 落地窗 动迁税费少 业主诚意卖">
                                <span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>
                                <div class="bottom">
                                    <div class="ppy-name">
                                        <p>闵行·闵浦</p>
                                        <p>金硕河畔景园东区</p>
                                    </div>
                                    <div class="ppy-info">
                                        2室2厅 · 71.98平米
                                        <div class="price">235万
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="agent">
            <div class="container">
                <div class="intro-title">
                    <div class="title-box">
                        <h1>金牌经纪人</h1>
                        <p>为更多的人找到满意的家 </p>
                        <!--<div class="title-link">-->
                        <!--<a href="/coding">查看更多-->
                        <!--<i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>-->
                        <!--</a>-->
                        <!--</div>-->
                    </div>

                </div>
                <div class="agent-box">
                    <ul>

                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>

                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="agent-box-a">
                            <div class="agent-box-b" style="">
                                <!--<img class="agent-avater" src="/PC/img/avater.png">-->
                                <img class="agent-box-img" src="/PC/img/agent-5.jpg"
                                     alt="经纪人姓名" title="经纪人姓名">
                                <!--<span class="goodhouse"><img src="https://img.ljcdn.com/beike/haofanglogo/1578296306747.png"></span>-->
                                <div class="bottom">
                                    <div class="agent-name">
                                        <p>孙路路</p>
                                        <span>好评经纪人，熟悉本房特色</span>
                                    </div>
                                    <div class="agent-mobile">
                                        13356783456
                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                    <div class="clearfix"></div>
                    <a id="prev" class="prev" href="#">&lt;</a>
                    <a id="next" class="next" href="#">&gt;</a>
                    <div id="pager" class="pager"></div>
                </div>
            </div>
        </section>
    </body>
    <script>
        new Vue({
            el:'#app',
            data:{
                name:'Hello GeJia'
            }
        })

    </script>
</html>
<?php /**PATH D:\Code\www.vikdoo.com\resources\views/welcome.blade.php ENDPATH**/ ?>